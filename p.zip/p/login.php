<html>
<head>
	<title>BOOKS - login</title>
	<link rel="stylesheet" href="style.css">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
 
</head>
<body div class="body1" />
	
		<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
      <a class="navbar-brand" href="indexx.php">BOOKS</a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
        <li class="active"><a href="indexx.php">Home</a></li>
        <li class="dropdown">
         
          <ul class="dropdown-menu">
            <li><a href="#"></a></li>
            <li><a href="#"></a></li>
            <li><a href="#"></a></li>
          </ul>
        </li>
        <li><a href="#"></a></li>
        <li><a href="#"></a></li>
      </ul>
      <ul class="nav navbar-nav navbar-right">

        <li><a href="login.php"><span ></span> Login</a></li>
      </ul>
    </div>
  </div>
</nav>
 

    <br><br><br><br><br><br><br><br><br><br>
    <form method="post" action="#">
    <center>
    <input type="text" name="username" placeholder="Enter Username" /><br /><br>
    <input type="password" name="password" placeholder="Enter Password"/><br /><br>
    <input type="submit" name="submit" value="Login" /><br />
    <a href="index.php">Back to Home</a><br />
    <center>
  </form>
  
	
	<?php
  $c = oci_connect("hr", "hr", "localhost/XE");

  if (!$c){
    $e = oci_error();
    trigger_error('Could not connect to database: ' . $e['message'], E_USER_ERROR);
  }

  
    if(isset($_POST['submit'])) {
      $username = $_POST['username'];
      $password = md5($_POST['password']);

  $s = oci_parse($c, "Select * From Borrower Where Username ='" . $username . "' and Password ='" . $password ."'");
  if(!$s){
    $e = oci_error($c);
    trigger_error('Could not parse statement: ' . $e['message'], E_USER_ERROR);
  }

  $r = oci_execute($s);
  if(!$r){
    $e = oci_error($c);
    trigger_error('Could not execute statement: ' . $e['message'], E_USER_ERROR);
  }

  $row = oci_fetch_array($s);

  $a = oci_num_rows($s);
  if(!$a){
    echo "Incorrect Username/ Password";
  }
  else {
    header('Location:index.php');
  }
      

    
    }

  ?>

		
</div>
</body>
</html>