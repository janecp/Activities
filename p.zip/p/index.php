<html>
<head>
	<title>BOOKS - login</title>
	<link rel="stylesheet" href="style.css">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
 
</head>
<body div class="body1" />
	
		<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
      <a class="navbar-brand" href="indexx.php">BOOKS</a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
        <li class="active"><a href="indexx.php">Home</a></li>
        <li class="dropdown">
         
          <ul class="dropdown-menu">
            <li><a href="#"></a></li>
            <li><a href="#"></a></li>
            <li><a href="#"></a></li>
          </ul>
        </li>
        <li><a href="#"></a></li>
        <li><a href="#"></a></li>
      </ul>
      <ul class="nav navbar-nav navbar-right">

        <li><a href="logout.php"><span ></span> Log Out</a></li>
      </ul>
    </div>
  </div>
</nav>
 

    <br><br><br><br><br>
    <center>
    <h1>WELCOME </h1>
	
<?php
	$c = oci_connect("hr", "hr", "localhost/XE");

	if (!$c){
		$e = oci_error();
		trigger_error('Could not connect to database: ' . $e['message'], E_USER_ERROR);
	}

	$s = oci_parse($c, "Select * From Books");
	if(!$s){
		$e = oci_error($c);
		trigger_error('Could not parse statement: ' . $e['message'], E_USER_ERROR);
	}

	$r = oci_execute($s);
	if(!$r){
		$e = oci_error($c);
		trigger_error('Could not execute statement: ' . $e['message'], E_USER_ERROR);
	}

	echo "<table border = '1'>\n";
	$ncols = oci_num_fields($s);
	echo "<tr>\n";
	for($i = 1; $i <= $ncols; ++$i){
		$colname = oci_field_name($s, $i);
		echo "<th><b>" .htmlentities($colname,ENT_QUOTES). "</b></th>\n"; 
	}

	echo "</tr>\n";
	while(($row = oci_fetch_array($s,OCI_ASSOC+OCI_RETURN_NULLS)) != FALSE){
		echo "<tr>\n";
		foreach($row as $item){
			echo "<td>" .($item !== null? htmlentities($item,ENT_QUOTES): "&nbsp;").
				"</td>\n"; 
		}
		echo "</tr>\n";
	}
	echo "</table>\n";

	?>
	</center>

</div>
</body>
</html>
